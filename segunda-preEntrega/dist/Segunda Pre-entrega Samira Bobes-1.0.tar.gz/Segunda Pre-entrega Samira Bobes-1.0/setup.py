from setuptools import setup

setup(
    name="Segunda Pre-entrega Samira Bobes",
    version="1.0",
    description="Segunda pre-entrega",
    author="Samira Bobes",
    author_email="samirabobes@gmail.com",
    packages=["Paquete1"]


)